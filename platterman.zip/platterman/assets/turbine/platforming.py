import pygame, random

winlength = 900
winheight = 900
win = pygame.display.set_mode((winlength, winheight))


class Player(object):
    def __init__(self, x, y, width, height, vel=5.0, health=1.0, jumplength=10, jumpheight=2, jumpmomentum=0.25
                 ):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.x2 = x + width
        self.y2 = y + width
        self.vel = vel
        self.health = health
        self.hitbox = pygame.Rect(x, y, width, height)
        self.isJump = False
        self.jumplength = jumplength
        self.jumpheight = jumpheight
        self.jumpmomentum = jumpmomentum
        self.neg = 1


class Particle(object):
    particles = []

    def __init__(self):
        pass

    def add(self, pos=None, vel=None, time=None):
        if pos is None:
            pos = [400, 500]
        if vel is None:
            vel = [random.randint(0, 20) / 10 - 1, -2]
        if time is None:
            time = random.randint(4, 6)
        self.particles.append([pos, vel, time])

    def run(self):
        for particle in self.particles:
            particle[0][0] += particle[1][0]
            particle[0][1] += particle[1][1]
            particle[2] -= 0.1
            particle[1][1] += 0.1

            pygame.draw.circle(win, (255, 255, 255), [int(particle[0][0]), int(particle[0][1])], int(particle[2]))

            if particle[2] <= 0:
                self.particles.remove(particle)
