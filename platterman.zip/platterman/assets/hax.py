active = False

startlevel = 1
noclip = False
flyspeed = 20
bumpyride = False
