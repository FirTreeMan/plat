active = False

startlevel = 4
noclip = True
flyspeed = 20
bumpyride = False
