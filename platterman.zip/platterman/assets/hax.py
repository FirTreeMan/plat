active = False

startlevel = 1
flyspeed = 20
