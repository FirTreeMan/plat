import pygame
import assets.turbine.platforming as platforming
from assets.data.data import levels as levels
# import os

pygame.init()
# os.environ['SDL_VIDEO_WINDOW_POS'] = '0, 0'
width = 1024
height = 1024
win = pygame.display.set_mode((width, height), pygame.FULLSCREEN | pygame.SCALED)
pygame.display.set_caption("Platman")
clock = pygame.time.Clock()
levelx = 0
levely = 0
blocktiles = []
lavatiles = []
nearbytiles = []
levelcount = -1
size = 32
currentlvl = [0]


space = pygame.image.load("assets/img/space.png")
block = pygame.image.load("assets/img/block.png")
escape = pygame.image.load("assets/img/escape.png")
lava = pygame.image.load("assets/img/lava.png")
spawn = pygame.image.load("assets/img/spawn.png")


class Player(platforming.Player):
    char = pygame.image.load("assets/img/platterman.png")

    def __init__(self, x, y):
        super().__init__(x, y, width=size / 2, height=size / 2, vel=10)
        self.acceleration = 1
        self.momentum = 0
        self.alive = True
        self.spawn = [5000, 5000]
        self.escape = pygame.Rect(-5000, -5000, size, size)
        self.vertforce = 0
        self.gravity = 2
        self.escaped = True
        self.canJump = False
        self.tvel = 20

    # block2 is named as such to prevent outer scope warning
    def jump(self):
        self.isJump = True
        while self.isJump:
            for block2 in blocktiles:
                if self.x > block2[0] or self.x2 < block2[2]:
                    if self.y > block2[3] > self.y - (self.jumplength ** self.jumpheight) * self.jumpmomentum * \
                            self.neg and self.neg == 1:
                        self.isJump = False
                    if self.y2 < block2[1] < self.y - (self.jumplength ** self.jumpheight) * self.jumpmomentum * \
                            self.neg and self.neg == -1:
                        self.isJump = False
            if self.jumplength >= -10:
                self.neg = 1
                if self.jumplength < 0:
                    self.neg = -1
                self.y -= (self.jumplength ** self.jumpheight) * self.jumpmomentum * self.neg
                self.jumplength -= 1
            else:
                self.isJump = False
                self.jumplength = 10

    def draw(self):
        win.blit(self.char, (self.x, self.y))

    def move(self):
        self.x2 = self.x + self.width
        self.y2 = self.y + self.height
        self.hitbox = pygame.Rect(self.x, self.y, self.width, self.height)

        keys = pygame.key.get_pressed()

        if not keys[pygame.K_a] and not keys[pygame.K_d] or keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT]:
            if self.momentum < 0:
                self.momentum += 1
            if self.momentum > 0:
                self.momentum -= 1
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            if abs(self.momentum - self.acceleration) < self.vel:
                self.momentum -= self.acceleration
            else:
                self.momentum = -self.vel
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            if self.momentum + self.acceleration < self.vel:
                self.momentum += self.acceleration
            else:
                self.momentum = self.vel
        if keys[pygame.K_SPACE] or keys[pygame.K_w] or keys[pygame.K_UP]:
            if self.canJump:
                self.vertforce = 10

        if self.momentum < self.vel * -1:
            self.momentum += self.acceleration
        if self.momentum > self.vel:
            self.momentum -= self.acceleration

        self.x2 = self.x + self.width
        self.y2 = self.y + self.height

        for tile1 in blocktiles:
            if abs(tile1.x / 32 - (int(-(-plat.x // 8)) - 1)) <= 1:
                if abs(height / 32 - tile1.y / 32 - (int(height / 32 - (-(-plat.y // 32))))) <= 1:
                    nearbytiles.append(tile1)

        for neartile in nearbytiles:
            if self.y <= neartile[1] or self.y2 >= neartile[3]:
                if self.x + self.momentum < neartile[2] and self.momentum < 0:
                    self.x = neartile[2]
                    self.momentum = 0
                if self.x2 + self.momentum > neartile[0] and self.momentum > 0:
                    self.x = neartile[0] - self.width
                    self.momentum = 0
            self.x += self.momentum

            self.x2 = self.x + self.width

            if self.x <= neartile[0] or self.x2 >= neartile[2]:
                if self.y2 - self.vertforce > neartile[1] and self.vertforce < 0:
                    self.y = neartile[1] - self.height
                    self.vertforce = 0
                    self.canJump = True
                if self.y - self.vertforce < neartile[3] and self.vertforce > 0:
                    self.y = neartile[1]
                    self.vertforce = 0
            self.y -= self.vertforce
            self.vertforce -= self.gravity
        # print(nearbytiles)


# strip1 and tile1 are named as such to prevent outer scope warning
def redrawgamewindow():
    levelx1 = 0
    levely1 = 0
    for strip1 in currentlvl:
        for tile1 in strip1:
            loaded = False
            if tile1 == 0:
                win.blit(space, (levelx1 * size, levely1 * size))
                loaded = True
                # print(levelx1, levely1)
            if tile1 == 1:
                win.blit(block, (levelx1 * size, levely1 * size))
                loaded = True
                pygame.draw.rect(win, (255, 255, 255), (levelx1 * size, levely1 * size, size, size), width=1)
                # print(levelx1, levely1)
            if tile1 == 2:
                win.blit(spawn, (levelx1 * size, levely1 * size))
                loaded = True
                # print(levelx1, levely1)
            if tile1 == 3:
                win.blit(lava, (levelx1 * size, levely1 * size))
                loaded = True
                # print(levelx1, levely1)
            if tile1 == 4:
                win.blit(escape, (levelx1 * size, levely1 * size))
                loaded = True
                # print(levelx1, levely1)
            if not loaded:
                print("Error 1: tiles cannot load")
                pygame.quit()
            levelx1 += 1
            # print(levelx1)
        levelx1 = 0
        levely1 += 1
        # print(levely1)
    # print(levelcount)
    plat.move()
    plat.draw()
    # print(plat.spawn)
    # print(plat.x, plat.y)
    pygame.display.flip()


# main loop
plat = Player(100, 100)
run = True
while run:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.KEYDOWN:
            if event.mod & pygame.KMOD_CTRL:
                if pygame.key.get_pressed()[pygame.K_w]:
                    run = False

    if plat.escaped is True:
        plat.escaped = False
        levelcount += 1
        # print(levelcount)
        currentlvl = levels[levelcount]
        blocktiles = []
        lavatiles = []

        for strip in currentlvl:
            for tile in strip:
                if tile == 0:
                    pass
                if tile == 1:
                    blocktiles.append(pygame.Rect(levelx, levely, levelx + size, levely + size))
                if tile == 2:
                    plat.spawn = [levelx + size / 4, levely + size / 2]
                if tile == 3:
                    lavatiles.append(pygame.Rect(levelx, levely, levelx + size, levely + size))
                if tile == 4:
                    plat.escape = pygame.Rect(levelx, levely, levelx + size, levely + size)
                levelx += 1 * size
            levelx = 0
            levely += 1 * size
        levely = 0
        plat.x, plat.y = plat.spawn[0], plat.spawn[1]

    if pygame.Rect.colliderect(plat.hitbox, plat.escape):
        plat.escaped = True

    if not plat.alive:
        plat.x, plat.y = plat.spawn[0], plat.spawn[1]
        plat.alive = True

    win.fill((0, 0, 0))
    win.blit(plat.char, (plat.x, plat.y))
    redrawgamewindow()
pygame.quit()
