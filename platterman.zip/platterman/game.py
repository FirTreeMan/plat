import pygame
from assets.data.data import levels as levels

# import os

pygame.init()
# os.environ['SDL_VIDEO_WINDOW_POS'] = '0, 0'
width = 1024
height = 1024
win = pygame.display.set_mode((width, height), pygame.FULLSCREEN | pygame.SCALED)
pygame.display.set_caption("Platman")
clock = pygame.time.Clock()
levelx = 0
levely = 0
spacetiles = pygame.sprite.Group()
blocktiles = pygame.sprite.Group()
lavatiles = pygame.sprite.Group()
escapetiles = pygame.sprite.Group()
sprites = pygame.sprite.Group()
nearbytiles = []
levelcount = -1
size = 32
currentlvl = [0]


class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.width = size / 2
        self.height = size / 2
        self.vel = 10
        self.acceleration = 1
        self.momentum = 0
        self.alive = True
        self.spawn = [5000, 5000]
        self.escape = pygame.Rect(-5000, -5000, size, size)
        self.vertforce = 0
        self.gravity = 0.05
        self.escaped = True
        self.canJump = False
        self.tvel = 20
        self.image = pygame.image.load("assets/img/platterman.png")
        self.rect = self.image.get_rect()
        self.levelcount = -1

    def draw(self):
        win.blit(self.image, (self.x, self.y))

    def move(self):
        self.x2 = self.x + self.width
        self.y2 = self.y + self.height

        keys = pygame.key.get_pressed()

        if keys[pygame.K_p]:
            self.y -= 20

        if not keys[pygame.K_a] and not keys[pygame.K_d] and not keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT]:
            if self.momentum < 0:
                self.momentum += 1
            if self.momentum > 0:
                self.momentum -= 1
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            if abs(self.momentum - self.acceleration) < self.vel:
                self.momentum -= self.acceleration
            else:
                self.momentum = -self.vel
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            if self.momentum + self.acceleration < self.vel:
                self.momentum += self.acceleration
            else:
                self.momentum = self.vel
        if keys[pygame.K_SPACE] or keys[pygame.K_w] or keys[pygame.K_UP]:
            if self.canJump:
                self.vertforce = 0.5

        if self.momentum < self.vel * -1:
            self.momentum += self.acceleration
        if self.momentum > self.vel:
            self.momentum -= self.acceleration

        self.x2 = self.x + self.width
        self.y2 = self.y + self.height

        self.canJump = False

        for neartile in nearbytiles:
            if self.x < neartile[2] or self.x2 > neartile[0]:
                # if self.y + self.vertforce < neartile[3] and self.vertforce < 0:
                #     self.vertforce = 0
                #     self.y = neartile[3]
                #     self.canJump = True
                # if self.y2 + self.vertforce > neartile[1] and self.vertforce > 0:
                #     self.vertforce = 0
                #     self.y = neartile[1] - self.height
                if not self.canJump:
                    if self.vertforce - self.gravity > self.tvel:
                        self.vertforce = self.tvel
                    else:
                        self.vertforce -= self.gravity
                self.y += self.vertforce


def die():
    plat.x = spawn.x + size / 4
    plat.y = spawn.y + size / 2


class Space(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.width = size
        self.height = size
        self.image = pygame.image.load("assets/img/space.png")
        self.rect = self.image.get_rect()


class Block(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.width = size
        self.height = size
        self.image = pygame.image.load("assets/img/block.png")
        self.rect = self.image.get_rect()


class Spawn(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.width = size
        self.height = size
        self.image = pygame.image.load("assets/img/spawn.png")
        self.rect = self.image.get_rect()


class Lava(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.width = size
        self.height = size
        self.image = pygame.image.load("assets/img/lava.png")
        self.rect = self.image.get_rect()


class Escape(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.width = size
        self.height = size
        self.image = pygame.image.load("assets/img/block.png")
        self.rect = self.image.get_rect()


# strip1 and tile1 are named as such to prevent outer scope warning
def redrawgamewindow():
    for sprite in sprites:
        win.blit(sprite.image, sprite.rect)
    plat.move()
    # print(plat.x, plat.y)
    pygame.display.flip()


# main loop
plat = Player(100, 100)
run = True
while run:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.KEYDOWN:
            if event.mod & pygame.KMOD_CTRL:
                if pygame.key.get_pressed()[pygame.K_w]:
                    run = False

    if plat.escaped is True:
        plat.escaped = False
        levelcount += 1
        # print(levelcount)
        currentlvl = levels[levelcount]
        spacetiles.empty()
        blocktiles.empty()
        spawn = Spawn(-10, -10)
        lavatiles.empty()
        escapetiles.empty()
        sprites.empty()

        for strip in currentlvl:
            for tile in strip:
                if tile == 0:
                    spacetiles.add(Space(levelx, levely))
                if tile == 1:
                    blocktiles.add(Block(levelx, levely))
                if tile == 2:
                    spawn = Spawn(levelx, levely)
                if tile == 3:
                    lavatiles.add(Lava(levelx, levely))
                if tile == 4:
                    escapetiles.add(Escape(levelx, levely))
                levelx += 1 * size
            levelx = 0
            levely += 1 * size
        levely = 0

        if spawn == Spawn(-10, -10):
            print("Error: no spawn found")
            run = False
        die()
        sprites.add(plat, spacetiles, blocktiles, spawn, lavatiles, escapetiles)

    if pygame.sprite.spritecollide(plat, lavatiles, False):
        die()
    if pygame.sprite.spritecollide(plat, escapetiles, False):
        plat.escaped = True

    win.fill((0, 0, 0))
    win.blit(plat.image, (plat.x, plat.y))
    redrawgamewindow()
pygame.quit()
