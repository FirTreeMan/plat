import pygame
import pygame.font as fonts
from assets.data.data import levels as levels
from assets.data.data import leveldescs as leveldescs
from assets.data.data import anims as anims
import assets.data.colors as colors
import assets.hax as hax
from enum import Enum, unique, auto
import random
from glitch_this import ImageGlitcher

invisiblespawn = False

# import os

pygame.init()
# hax.active = True
# os.environ['SDL_VIDEO_WINDOW_POS'] = '0, 0'
screenwidth = 1072
screenheight = 1072
width = 1024
height = 1024
zoom = 1
win = pygame.display.set_mode((screenwidth / zoom, screenheight / zoom), pygame.FULLSCREEN | pygame.SCALED)
pygame.display.set_caption("Platman")
clock = pygame.time.Clock()
levelx = 0
levely = 0
cutscene = False
cutscenecount = 0
glitcher = ImageGlitcher()
glitchimg = pygame.image.load("assets/img/escape.png")

prespacetiles = []
spacetiles = pygame.sprite.Group()
preblocktiles = []
blocktiles = pygame.sprite.Group()
prespawn = []
prelavatiles = []
lavatiles = pygame.sprite.Group()
preesctiles = []
esctiles = pygame.sprite.Group()
preelevtiles = []
elevtiles = pygame.sprite.Group()
precircuittiles = []
circuittiles = pygame.sprite.Group()
preswitchtiles = []
switchtiles = pygame.sprite.Group()
predoortiles = []
doortiles = pygame.sprite.Group()
prerocktiles = []
rocktiles = pygame.sprite.Group()
preturrettiles = []
turrettiles = pygame.sprite.Group()
bullets = pygame.sprite.Group()
prelighttiles = []
lighttiles = pygame.sprite.Group()
lightingtiles = pygame.sprite.Group()
prevortextiles = []
vortextiles = pygame.sprite.Group()
sprites = pygame.sprite.Group()
sprites2 = pygame.sprite.Group()
collidetiles = pygame.sprite.Group()
elevcollidetiles = pygame.sprite.Group()
solidtiles = pygame.sprite.Group()

ost = pygame.mixer.music
crush = pygame.mixer.Sound("assets/sfx/crush.ogg")
melt = pygame.mixer.Sound("assets/sfx/melt.ogg")
shoot = pygame.mixer.Sound("assets/sfx/shoot.ogg")
hit = pygame.mixer.Sound("assets/sfx/hit.ogg")
shotkill = pygame.mixer.Sound("assets/sfx/shotkill.ogg")

if hax.active:
    levelcount = hax.startlevel - 2
else:
    levelcount = 2
size = 32
currentlvl = [0]
powered = []
lights = pygame.surface.Surface((1024, 1024))
stealth = False


class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.momentum = 0
        self.baseaccel = 1
        self.airaccel = 0.5
        self.acceleration = 0
        self.vel = 8
        self.alive = True
        self.vertforce = 0
        self.gravity = 0.7
        self.jumpheight = 14
        self.tvel = 21
        self.jumping = False
        self.grounded = False
        self.escaped = True
        self.image = pygame.image.load("assets/img/platterman.png")
        self.rect = self.image.get_rect()
        self.levelcount = -1
        self.coyotetime = 4
        self.buffertime = 0
        self.buffering = False
        self.mask = pygame.mask.from_surface(self.image)
        self.killtimer = 1

    def gravitycalc(self):
        self.grounded = False
        self.buffering = False
        self.rect.y += 3
        grounded = pygame.sprite.spritecollide(plat, collidetiles, False)
        if len(grounded) > 0 or self.rect.bottom >= height:
            self.rect.y -= 3
            self.grounded = True
        else:
            self.rect.y -= 3
            if self.jumping or self.vertforce < 0 or self.vertforce - self.gravity >= 0:
                if self.vertforce - self.gravity < -self.tvel:
                    self.vertforce = -self.tvel
                else:
                    self.vertforce -= self.gravity
            else:
                if self.buffertime > 0:
                    if self.buffertime == self.coyotetime:
                        self.rect.y += 1
                    self.buffertime -= 1
                    self.buffering = True
                else:
                    self.vertforce -= self.gravity
        if self.grounded:
            self.jumping = False
            self.buffertime = self.coyotetime

    def move(self):
        # acceleration:vel ratio = 1:8
        # gravity:jumpheight:tvel ratio = 1:20:30

        # change motion values correspondingly to achieve different levels of "controlled speed" and "jump power"

        if not plat.alive:
            if self.killtimer > 0:
                self.killtimer -= 1
            else:
                plat.alive = True
                self.killtimer = 1

        keys = pygame.key.get_pressed()

        if not cutscene:

            if keys[pygame.K_p] and hax.active:
                self.rect.y -= hax.flyspeed
            self.gravitycalc()

            if self.grounded:
                self.acceleration = self.baseaccel
            else:
                self.acceleration = self.airaccel

            if not keys[pygame.K_a] and not keys[pygame.K_d] and not keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT]:
                if self.momentum < 0:
                    if self.grounded:
                        if self.momentum > -self.baseaccel:
                            self.momentum = 0
                        else:
                            self.momentum += self.acceleration
                    else:
                        self.momentum += self.airaccel
                if self.momentum > 0:
                    if self.grounded:
                        if self.momentum < self.baseaccel:
                            self.momentum = 0
                        else:
                            self.momentum -= self.acceleration
                    else:
                        self.momentum -= self.airaccel
            if keys[pygame.K_a] or keys[pygame.K_LEFT]:
                if not hax.active or not hax.noclip:
                    if abs(self.momentum - self.acceleration) < self.vel:
                        self.momentum -= self.acceleration
                    else:
                        self.momentum = -self.vel
                else:
                    self.rect.x -= hax.flyspeed
            if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
                if not hax.active or not hax.noclip:
                    if self.momentum + self.acceleration < self.vel:
                        self.momentum += self.acceleration
                    else:
                        self.momentum = self.vel
                else:
                    self.rect.x += hax.flyspeed
            if keys[pygame.K_SPACE] or keys[pygame.K_w] or keys[pygame.K_UP]:
                if not hax.active or not hax.noclip:
                    if self.grounded or self.buffering:
                        self.vertforce += self.jumpheight
                        self.jumping = True
                else:
                    self.rect.y -= hax.flyspeed
            if keys[pygame.K_s] or keys[pygame.K_DOWN]:
                if not hax.active or not hax.noclip:
                    pass
                else:
                    self.rect.y += hax.flyspeed
        else:
            self.momentum = 0
            self.vertforce = 0

        if self.momentum < self.vel * -1:
            self.momentum = self.vel * -1
        if self.momentum > self.vel:
            self.momentum = self.vel

        self.rect.x += self.momentum
        collidedtiles = pygame.sprite.spritecollide(plat, collidetiles, False)

        for tile1 in collidedtiles:
            if self.momentum > 0:
                self.rect.right = tile1.rect.left
                self.momentum = 0
            elif self.momentum < 0:
                self.rect.left = tile1.rect.right
                self.momentum = 0
        if self.rect.right > width:
            self.rect.right = width
            self.momentum = 0
        if self.rect.left < 0:
            self.rect.left = 0
            self.momentum = 0

        self.rect.y -= self.vertforce
        collidedtiles = pygame.sprite.spritecollide(plat, collidetiles, False)

        for tile1 in collidedtiles:
            if self.vertforce < 0:
                self.rect.bottom = tile1.rect.top
                self.vertforce = 0
            elif self.vertforce > 0:
                self.rect.top = tile1.rect.bottom
                self.vertforce = 0
        if self.rect.bottom > height:
            self.rect.bottom = height
            self.vertforce = 0
        if self.rect.top < 0:
            self.rect.top = 0
            self.vertforce = 0

        collidedtiles = pygame.sprite.spritecollide(plat, collidetiles, False)
        if len(collidedtiles) > 0:
            if not hax.active or not hax.noclip:
                for i in range(6):
                    particlesys.add(pos=plat.rect.center, vel=[random.randint(0, 20) / 10 - 1,
                                                               random.randint(-15, -10)], gravity=0.75, time=10,
                                    decay=0.01, color=(190, 195, 199))
                crush.play()
                die()


def die():
    if not hax.active or not hax.noclip:
        plat.rect.x = spawn.x + size / 4
        plat.rect.y = spawn.y + size / 2
        plat.alive = False
        elevtiles.update()
        doortiles.update()


class Particle(object):
    particles = []

    def __init__(self):
        pass

    def add(self, pos=None, vel=None, time=None, decay=None, gravity=None, color=None):
        if pos is None:
            pos = [400, 500]
        pos = list(pos)
        if vel is None:
            vel = [random.randint(0, 20) / 10 - 1, -2]
        if time is None:
            time = random.randint(4, 6)
        if decay is None:
            decay = 0.1
        if gravity is None:
            gravity = abs(vel[1] / 20)
        if color is None:
            color = (255, 255, 255)
        self.particles.append({'pos': pos,
                               'vel': vel,
                               'time': time,
                               'decay': decay,
                               'gravity': gravity,
                               'color': color})

    def run(self, shape="circle"):
        for particle in self.particles:
            particle['pos'][0] += particle['vel'][0]
            particle['pos'][1] += particle['vel'][1]
            particle['time'] -= particle['decay']
            particle['vel'][1] += particle['gravity']

            if shape == "circle":
                pygame.draw.circle(win, particle['color'], [int(particle['pos'][0]), int(particle['pos'][1])],
                                   int(particle['time']))
            if shape == "square":
                pygame.draw.rect(win, particle['color'], [particle['pos'][0] - particle['time'] / 2,
                                                          particle['pos'][1] - particle['time'] / 2, particle['time'],
                                                          particle['time']])

            if particle['time'] <= 0:
                self.particles.remove(particle)


# noinspection PyArgumentList
@unique
class Direction(Enum):
    up = auto()
    left = auto()
    down = auto()
    right = auto()


class Demo(pygame.sprite.Sprite):
    def __init__(self, image, rect):
        super().__init__()
        self.image = image
        self.rect = rect


def power(image, rect):
    powered.clear()

    tempsprite = Demo(image, rect)

    tempsprite.rect.y -= 1
    uppower = pygame.sprite.spritecollide(tempsprite, rocktiles, False)
    upblock = pygame.sprite.spritecollide(tempsprite, doortiles, False)
    tempsprite.rect.y += 1

    tempsprite.rect.x -= 1
    leftpower = pygame.sprite.spritecollide(tempsprite, rocktiles, False)
    leftblock = pygame.sprite.spritecollide(tempsprite, doortiles, False)
    tempsprite.rect.x += 1

    tempsprite.rect.y += 1
    downpower = pygame.sprite.spritecollide(tempsprite, rocktiles, False)
    downblock = pygame.sprite.spritecollide(tempsprite, doortiles, False)
    tempsprite.rect.y -= 1

    tempsprite.rect.x += 1
    rightpower = pygame.sprite.spritecollide(tempsprite, rocktiles, False)
    rightblock = pygame.sprite.spritecollide(tempsprite, doortiles, False)
    tempsprite.rect.x -= 1

    if len(uppower) > len(upblock):
        powered.append(Direction.up)
    if len(leftpower) > len(leftblock):
        powered.append(Direction.left)
    if len(downpower) > len(downblock):
        powered.append(Direction.down)
    if len(rightpower) > len(rightblock):
        powered.append(Direction.right)


def glitch(image):
    global glitchimg
    random.seed(random.randint(1, 20000000))
    x = random.random()
    glitchimg = glitcher.glitch_image(src_img=image, glitch_amount=5, seed=x, color_offset=True, frames=1)
    glitchimg.save(r"assets\img\anims\glitchimg.png", format="PNG")


def animate():
    global cutscenecount
    time = 0
    live = True
    if live:
        if cutscenecount == 0:
            vortextiles.update()

        time += 1
    else:
        cutscenecount += 1
        plat.baseaccel = 1
        plat.airaccel = 0.5
        plat.acceleration = 0
        plat.vel = 8
        plat.vertforce = 0
        plat.gravity = 0.7
        plat.jumpheight = 14
        plat.tvel = 21
        plat.jumping = False
        plat.grounded = False


class Space(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("assets/img/space.png")
        self.rect = self.image.get_rect()


class Block(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("assets/img/block.png")
        self.rect = self.image.get_rect()


class Spawn(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("assets/img/spawn.png")
        if invisiblespawn:
            self.image = pygame.image.load("assets/img/space.png")
        self.rect = self.image.get_rect()


class Lava(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("assets/img/lava.png")
        self.rect = self.image.get_rect()


class Esc(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("assets/img/escape.png")
        self.rect = self.image.get_rect()


class Elev(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("assets/img/elevator.png")
        self.rect = self.image.get_rect()
        self.direction = 0
        self.speed = 2

    def update(self):
        if not plat.alive:
            self.rect.x, self.rect.y = self.x, self.y

        else:
            if hax.active and hax.bumpyride:
                charcollide = pygame.sprite.collide_rect(self, plat)
            else:
                plat.rect.y += 3
                charcollide = pygame.sprite.collide_rect(self, plat)
                plat.rect.y -= 3

            self.rect.y -= self.speed
            upcollidedtiles = pygame.sprite.spritecollide(self, circuittiles, False)
            upcanmove = pygame.sprite.spritecollide(self, elevcollidetiles, False)
            self.rect.y += self.speed

            self.rect.x -= self.speed
            leftcollidedtiles = pygame.sprite.spritecollide(self, circuittiles, False)
            leftcanmove = pygame.sprite.spritecollide(self, elevcollidetiles, False)
            self.rect.x += self.speed

            self.rect.y += self.speed
            downcollidedtiles = pygame.sprite.spritecollide(self, circuittiles, False)
            downcanmove = pygame.sprite.spritecollide(self, elevcollidetiles, False)
            self.rect.y -= self.speed

            self.rect.x += self.speed
            rightcollidedtiles = pygame.sprite.spritecollide(self, circuittiles, False)
            rightcanmove = pygame.sprite.spritecollide(self, elevcollidetiles, False)
            self.rect.x -= self.speed

            if self.direction == 0:
                self.direction = Direction.up

            if self.direction == Direction.up:
                if len(upcanmove) == 0 and len(upcollidedtiles) > 0 and self.rect.top - self.speed >= 0:
                    self.rect.y -= self.speed
                    if hax.active and hax.bumpyride:
                        if not charcollide:
                            if pygame.sprite.collide_rect(self, plat):
                                plat.rect.y -= self.speed
                    else:
                        if charcollide or pygame.sprite.collide_rect(self, plat):
                            plat.rect.y -= self.speed
                else:
                    self.direction = Direction.left
            if self.direction == Direction.left:
                if len(leftcanmove) == 0 and len(leftcollidedtiles) > 0 and self.rect.left - self.speed >= 0:
                    self.rect.x -= self.speed
                    if hax.active and hax.bumpyride:
                        if not charcollide:
                            if pygame.sprite.collide_rect(self, plat):
                                plat.rect.x -= self.speed
                    else:
                        if charcollide or pygame.sprite.collide_rect(self, plat):
                            plat.rect.x -= self.speed
                else:
                    self.direction = Direction.down
            if self.direction == Direction.down:
                if len(downcanmove) == 0 and len(downcollidedtiles) > 0 and self.rect.bottom + self.speed <= height:
                    self.rect.y += self.speed
                    if hax.active and hax.bumpyride:
                        if not charcollide:
                            if pygame.sprite.collide_rect(self, plat):
                                plat.rect.y += self.speed
                    else:
                        if charcollide or pygame.sprite.collide_rect(self, plat):
                            collision = True
                            if plat.grounded:
                                if plat.rect.left < self.rect.left:
                                    self.rect.x -= 2
                                    collidedtiles = pygame.sprite.spritecollide(self, collidetiles, False)
                                    self.rect.x += 2
                                    if len(collidedtiles) == 3:
                                        collision = False
                                if plat.rect.right < self.rect.right:
                                    self.rect.x += 2
                                    collidedtiles = pygame.sprite.spritecollide(self, collidetiles, False)
                                    self.rect.x -= 2
                                    if len(collidedtiles) == 3:
                                        collision = False
                            if collision:
                                plat.rect.y += self.speed
                else:
                    self.direction = Direction.right
            if self.direction == Direction.right:
                if len(rightcanmove) == 0 and len(rightcollidedtiles) > 0 and self.rect.right + self.speed <= width:
                    self.rect.x += self.speed
                    if hax.active and hax.bumpyride:
                        if not charcollide:
                            if pygame.sprite.collide_rect(self, plat):
                                plat.rect.x += self.speed
                    else:
                        if charcollide or pygame.sprite.collide_rect(self, plat):
                            plat.rect.x += self.speed
                else:
                    self.direction = Direction.up


class Circuit(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("assets/img/circuit.png")
        self.rect = self.image.get_rect()


class Switch(pygame.sprite.Sprite):
    def __init__(self, x, y, ident):
        super().__init__()
        self.x = x
        self.y = y
        self.ident = ident
        self.image = pygame.image.load("assets/img/switch.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.pressed = False
        self.mask = pygame.mask.from_surface(self.image)

    def update(self):
        if pygame.sprite.collide_mask(plat, self):
            if not self.pressed:
                self.pressed = True
                doortiles.update(self.ident)
        else:
            self.pressed = False


class Door(pygame.sprite.Sprite):
    def __init__(self, x, y, ident):
        super().__init__()
        self.x = x
        self.y = y
        self.ident = ident
        self.image = pygame.image.load("assets/img/door.png").convert_alpha()
        self.rect = self.image.get_rect()

    def update(self, ident=-1):
        if not plat.alive:
            sprites2.add(self)
            collidetiles.add(self)
            elevcollidetiles.add(self)
            solidtiles.add(self)
        else:
            if self.ident == ident:
                if sprites2.has(self):
                    self.kill()
                    self.add(doortiles)
                else:
                    sprites2.add(self)
                    collidetiles.add(self)
                    elevcollidetiles.add(self)
                    solidtiles.add(self)


class Rock(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("assets/img/hotrock.png")
        self.rect = self.image.get_rect()


class Turret(pygame.sprite.Sprite):
    def __init__(self, x, y, firerate=60, delay=0):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("assets/img/turret.png")
        self.rect = self.image.get_rect()
        self.firerate = firerate
        self.delay = delay
        self.cooldown = 0

    def update(self):
        if self.delay > 0:
            self.delay -= 1
        else:
            if self.cooldown > 0:
                self.cooldown -= 1

            if self.cooldown <= 0:

                power(self.image, self.rect)

                if Direction.up in powered:
                    bullets.add(Bullet(self.rect.midbottom[0] - size / 8, self.rect.midbottom[1] + size / 4,
                                       Direction.down))
                if Direction.left in powered:
                    bullets.add(Bullet(self.rect.midright[0] + size / 4, self.rect.midright[1] - size / 8,
                                       Direction.right))
                if Direction.down in powered:
                    bullets.add(Bullet(self.rect.midtop[0] - size / 8, self.rect.midtop[1] - size / 4,
                                       Direction.up))
                if Direction.right in powered:
                    bullets.add(Bullet(self.rect.midleft[0] - size / 4, self.rect.midleft[1] - size / 8,
                                       Direction.left))
                self.cooldown = self.firerate
                shoot.play()


class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction, speed=5):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("assets/img/bullet.png")
        self.rect = self.image.get_rect()
        self.direction = direction
        self.speed = speed
        self.set = False

    def update(self):
        if not self.set:
            self.set = True
            self.rect.x, self.rect.y = self.x, self.y
        if self.direction == Direction.up:
            self.rect.y -= self.speed
        if self.direction == Direction.left:
            self.rect.x -= self.speed
        if self.direction == Direction.down:
            self.rect.y += self.speed
        if self.direction == Direction.right:
            self.rect.x += self.speed

        collided = pygame.sprite.spritecollide(self, solidtiles, False)
        collided2 = pygame.sprite.collide_rect(self, plat)
        if collided or self.rect.left < 0 or self.rect.right > width or self.rect.top < 0 or self.rect.bottom > height:
            self.kill()
            hit.play()
        if collided2:
            self.kill()
            die()
            shotkill.play()


class Light(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("assets/img/stealth/light.png")
        self.rect = self.image.get_rect()

    def update(self):
        power(self.image, self.rect)

        if Direction.up in powered:
            lightingtiles.add(Lighting(self.rect.midbottom[0] - width / 2, self.rect.midbottom[1], 0))
        if Direction.left in powered:
            lightingtiles.add(Lighting(self.rect.midright[0], self.rect.midright[1] - width / 2, 90))
        if Direction.down in powered:
            lightingtiles.add(Lighting(self.rect.midtop[0] - width / 2, self.rect.midtop[1], 180))
        if Direction.right in powered:
            lightingtiles.add(Lighting(self.rect.midleft[0], self.rect.midleft[1] - width / 2, 270))


class Lighting(pygame.sprite.Sprite):
    def __init__(self, x, y, rotation=0):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.transform.rotate(pygame.image.load("assets/img/stealth/lighting.png"), rotation)
        self.rect = self.image.get_rect()
        self.set = False

    def update(self):
        if not self.set:
            self.set = True
            self.rect.x, self.rect.y = self.x, self.y
        lights.blit(self.image, self.rect)


class Vortex(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.x = x
        self.y = y
        self.rawimg = image
        self.image = pygame.image.load(image)
        self.rect = self.image.get_rect()

    def update(self):
        glitch(self.rawimg)
        self.rawimg = glitchimg
        self.image = pygame.image.load("assets/img/anims/glitchimg.png")


def redrawgamewindow():
    sprites.draw(win)
    sprites2.draw(win)
    bullets.draw(win)
    particlesys.run("square")
    win.blit(leveltext, (4, 1024))
    win.blit(plat.image, plat.rect)
    vortextiles.draw(win)
    if len(lighttiles) > 0:
        win.blit(lights, (0, 0), special_flags=pygame.BLEND_RGBA_SUB)
    pygame.display.flip()


# final inits
plat = Player()
plat.rect.x, plat.rect.y = 100, 100
particlesys = Particle()

font1 = fonts.Font("assets/data/fonts/pixel-piss.ttf", 20)
leveltext = font1.render("???", False, colors.WHITE)

# main loop
run = True
while run:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.KEYDOWN:
            if event.mod & pygame.KMOD_CTRL:
                if pygame.key.get_pressed()[pygame.K_w]:
                    run = False

    if plat.escaped is True:
        plat.escaped = False
        levelcount += 1
        # print(levelcount)
        # print("escaped")
        if not cutscene:
            currentlvl = levels[levelcount]
            leveltext = font1.render(f"Level {levelcount + 1} : {leveldescs[levelcount]}", False, colors.WHITE)
        else:
            currentlvl = anims[cutscenecount]
            leveltext = font1.render("", False, colors.WHITE)

        prespacetiles.clear()
        spacetiles.empty()
        preblocktiles.clear()
        blocktiles.empty()
        prespawn = []
        spawn = Spawn(-10, -10)
        prelavatiles.clear()
        lavatiles.empty()
        preesctiles.clear()
        esctiles.empty()
        preelevtiles.clear()
        elevtiles.empty()
        precircuittiles.clear()
        circuittiles.empty()
        preswitchtiles.clear()
        switchtiles.empty()
        predoortiles.clear()
        doortiles.empty()
        prerocktiles.clear()
        rocktiles.empty()
        preturrettiles.clear()
        turrettiles.empty()
        bullets.empty()
        stealth = False
        prelighttiles.clear()
        lighttiles.empty()
        lightingtiles.empty()
        sprites.empty()
        sprites2.empty()
        collidetiles.empty()
        elevcollidetiles.empty()
        solidtiles.empty()

        for strip in currentlvl:
            for tile in strip:
                if tile == 0:
                    prespacetiles.append([levelx, levely])
                if tile == 1:
                    preblocktiles.append([levelx, levely])
                if tile == 2:
                    prespawn.append([levelx, levely])
                if tile == 3:
                    prelavatiles.append([levelx, levely])
                if tile == 4:
                    preesctiles.append([levelx, levely])
                if tile == 5:
                    precircuittiles.append([levelx, levely])
                    preelevtiles.append([levelx, levely])
                if tile == 6:
                    precircuittiles.append([levelx, levely])
                if tile == 9:
                    prerocktiles.append([levelx, levely])
                if type(tile) == list:
                    if tile[0] == 7:
                        prespacetiles.append([levelx, levely])
                        preswitchtiles.append([levelx, levely, tile[1]])
                    if tile[0] == 8:
                        if tile[2] == 0:
                            prespacetiles.append([levelx, levely])
                        if tile[2] == 1:
                            preblocktiles.append([levelx, levely])
                        if tile[2] == 2:
                            prespawn.append([levelx, levely])
                        if tile[2] == 3:
                            prelavatiles.append([levelx, levely])
                        if tile[2] == 4:
                            preesctiles.append([levelx, levely])
                        if tile[2] == 5:
                            preelevtiles.append([levelx, levely])
                        if tile[2] == 6:
                            precircuittiles.append([levelx, levely])
                        if tile[2] == 9:
                            prerocktiles.append([levelx, levely])
                        if tile[2] == 10:
                            preturrettiles.append([levelx, levely])
                        if tile[2] == 11:
                            prelighttiles.append([levelx, levely])
                        predoortiles.append([levelx, levely, tile[1]])
                    if tile[0] == 10:
                        if len(tile) >= 3:
                            preturrettiles.append([levelx, levely, tile[1], tile[2]])
                        else:
                            preturrettiles.append([levelx, levely, tile[1]])
                    if tile[0] == 12:
                        if tile[1] == -1:
                            prevortextiles.append([levelx, levely, "assets/img/anims/greenglitch.png"])
                        if tile[1] == 0:
                            prevortextiles.append([levelx, levely, "assets/img/space.png"])
                        if tile[1] == 1:
                            prevortextiles.append([levelx, levely, "assets/img/block.png"])
                        if tile[1] == 2:
                            prevortextiles.append([levelx, levely, "assets/img/spawn.png"])
                        if tile[1] == 3:
                            prevortextiles.append([levelx, levely, "assets/img/lava.png"])
                        if tile[1] == 4:
                            prevortextiles.append([levelx, levely, "assets/img/escape.png"])
                        if tile[1] == 5:
                            prevortextiles.append([levelx, levely, "assets/img/circuit.png"])
                        if tile[1] == 6:
                            prevortextiles.append([levelx, levely, "assets/img/elevator.png"])

                levelx += 1 * size
            levelx = 0
            levely += 1 * size
        levely = 0

        for pre in prespacetiles:
            tile = Space(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            spacetiles.add(tile)
        for pre in preblocktiles:
            tile = Block(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            blocktiles.add(tile)
        for pre in prespawn:
            tile = Spawn(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            spawn = tile
        for pre in prelavatiles:
            tile = Lava(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            lavatiles.add(tile)
        for pre in preesctiles:
            tile = Esc(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            esctiles.add(tile)
        for pre in preelevtiles:
            tile = Elev(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            elevtiles.add(tile)
        for pre in precircuittiles:
            tile = Circuit(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            circuittiles.add(tile)
        for pre in preswitchtiles:
            tile = Switch(pre[0], pre[1], pre[2])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            switchtiles.add(tile)
        for pre in predoortiles:
            tile = Door(pre[0], pre[1], pre[2])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            doortiles.add(tile)
        for pre in prerocktiles:
            tile = Rock(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            rocktiles.add(tile)
        for pre in preturrettiles:
            if len(pre) == 4:
                tile = Turret(pre[0], pre[1], pre[2], pre[3])
            elif len(pre) == 3:
                tile = Turret(pre[0], pre[1], pre[2])
            else:
                tile = Turret(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            turrettiles.add(tile)
        for pre in prevortextiles:
            tile = Vortex(pre[0], pre[1], pre[2])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            vortextiles.add(tile)
        for pre in prelighttiles:
            tile = Light(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            lighttiles.add(tile)

        if spawn == Spawn(-10, -10):
            print("Error: No spawn found")
            run = False
        if len(lighttiles) > 0:
            stealth = True

        sprites.add(spacetiles, blocktiles, spawn, lavatiles, esctiles, circuittiles, rocktiles, turrettiles,
                    lighttiles)
        sprites2.add(elevtiles, switchtiles, doortiles)
        collidetiles.add(blocktiles, elevtiles, doortiles, rocktiles, turrettiles, lighttiles)
        elevcollidetiles.add(spacetiles, blocktiles, spawn, lavatiles, esctiles, switchtiles, doortiles, rocktiles,
                             turrettiles, lighttiles)
        solidtiles.add(blocktiles, spawn, lavatiles, esctiles, elevtiles, doortiles, rocktiles, turrettiles, lighttiles)

        die()

    if pygame.sprite.spritecollide(plat, lavatiles, False):
        melt.play()
        die()
    if pygame.sprite.spritecollide(plat, esctiles, False):
        cutscene = False
        invisiblespawn = False
        if levelcount == 4 - 1:
            cutscene = True
            invisiblespawn = True
            zoom = 12
            win = pygame.display.set_mode((screenwidth / zoom, screenheight / zoom), pygame.FULLSCREEN | pygame.SCALED)
        plat.escaped = True
    if cutscene:
        animate()

    elevtiles.update()
    switchtiles.update()
    turrettiles.update()
    bullets.update()
    lighttiles.update()
    plat.move()

    lights.fill(colors.DGRAY)
    lightingtiles.update()

    win.fill((0, 0, 0))
    redrawgamewindow()
pygame.quit()
