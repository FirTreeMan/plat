import pygame
import pygame.font as fonts
from assets.data.data import levels as levels
from assets.data.data import leveldescs as leveldescs
import assets.data.colors as colors

# import os

pygame.init()
# os.environ['SDL_VIDEO_WINDOW_POS'] = '0, 0'
screenwidth = 1072
screenheight = 1072
width = 1024
height = 1024
win = pygame.display.set_mode((screenwidth, screenheight), pygame.FULLSCREEN | pygame.SCALED)
pygame.display.set_caption("Platman")
clock = pygame.time.Clock()
levelx = 0
levely = 0
prespacetiles = []
spacetiles = pygame.sprite.Group()
preblocktiles = []
blocktiles = pygame.sprite.Group()
prespawn = []
prelavatiles = []
lavatiles = pygame.sprite.Group()
preesctiles = []
esctiles = pygame.sprite.Group()
sprites = pygame.sprite.Group()
nearbytiles = []
levelcount = -1
size = 32
currentlvl = [0]


class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.width = size / 2
        self.height = size / 2
        self.momentum = 0
        self.acceleration = 1
        self.vel = 10
        self.alive = True
        self.spawn = [5000, 5000]
        self.escape = pygame.Rect(-5000, -5000, size, size)
        self.vertforce = 0
        self.gravity = 0.7
        self.jumpheight = 14
        self.tvel = 21
        self.escaped = True
        self.grounded = False
        self.image = pygame.image.load("assets/img/platterman.png")
        self.rect = self.image.get_rect()
        self.levelcount = -1

    def gravitycalc(self):
        self.grounded = False
        self.rect.y += 2
        grounded = pygame.sprite.spritecollide(plat, blocktiles, False)
        if len(grounded) > 0:
            self.rect.y -= 2
            self.grounded = True
        else:
            self.rect.y -= 2
            if self.vertforce - self.gravity < -self.tvel or self.rect.bottom >= height:
                self.vertforce = -self.tvel
            else:
                self.vertforce -= self.gravity

    def move(self):
        # acceleration:vel ratio = 1:10
        # gravity:jumpheight:tvel ratio = 1:20:30

        # change motion values correspondingly to achieve different levels of "controlled speed" and "jump power"

        keys = pygame.key.get_pressed()

        if keys[pygame.K_p]:
            self.rect.y -= 20
        self.gravitycalc()

        if not keys[pygame.K_a] and not keys[pygame.K_d] and not keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT]:
            if self.momentum < 0:
                self.momentum += 1
            if self.momentum > 0:
                self.momentum -= 1
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            if abs(self.momentum - self.acceleration) < self.vel:
                self.momentum -= self.acceleration
            else:
                self.momentum = -self.vel
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            if self.momentum + self.acceleration < self.vel:
                self.momentum += self.acceleration
            else:
                self.momentum = self.vel
        if keys[pygame.K_SPACE] or keys[pygame.K_w] or keys[pygame.K_UP]:
            if self.grounded:
                self.vertforce += self.jumpheight

        if self.momentum < self.vel * -1:
            self.momentum += self.acceleration
        if self.momentum > self.vel:
            self.momentum -= self.acceleration

        self.rect.x += self.momentum
        collidedtiles = pygame.sprite.spritecollide(plat, blocktiles, False)

        for tile1 in collidedtiles:
            if self.momentum > 0:
                self.rect.right = tile1.rect.left
                self.momentum = 0
            elif self.momentum < 0:
                self.rect.left = tile1.rect.right
                self.momentum = 0
        if self.rect.right > width:
            self.rect.right = width
            self.momentum = 0
        if self.rect.left < 0:
            self.rect.left = 0
            self.momentum = 0

        self.rect.y -= self.vertforce
        collidedtiles = pygame.sprite.spritecollide(plat, blocktiles, False)

        for tile1 in collidedtiles:
            if self.vertforce < 0:
                self.rect.bottom = tile1.rect.top
                self.vertforce = 0
            elif self.vertforce > 0:
                self.rect.top = tile1.rect.bottom
                self.vertforce = 0
        if self.rect.bottom > height:
            self.rect.bottom = height
            self.vertforce = 0
        if self.rect.top < 0:
            self.rect.top = 0
            self.vertforce = 0


def die():
    plat.rect.x = spawn.x + size / 4
    plat.rect.y = spawn.y + size / 2


class Space(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.width = size
        self.height = size
        self.image = pygame.image.load("assets/img/space.png")
        self.rect = self.image.get_rect()


class Block(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.width = size
        self.height = size
        self.image = pygame.image.load("assets/img/block.png")
        self.rect = self.image.get_rect()


class Spawn(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.width = size
        self.height = size
        self.image = pygame.image.load("assets/img/spawn.png")
        self.rect = self.image.get_rect()


class Lava(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.width = size
        self.height = size
        self.image = pygame.image.load("assets/img/lava.png")
        self.rect = self.image.get_rect()


class Esc(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y
        self.width = size
        self.height = size
        self.image = pygame.image.load("assets/img/escape.png")
        self.rect = self.image.get_rect()


def redrawgamewindow():
    for sprite in sprites:
        win.blit(sprite.image, sprite.rect)
    win.blit(leveltext, (4, 1024))
    plat.move()
    win.blit(plat.image, plat.rect)
    # print(plat.rect.x, plat.rect.y)
    pygame.display.flip()


# final inits
plat = Player()
plat.rect.x, plat.rect.y = 100, 100

font1 = fonts.Font("assets/data/fonts/pixel-piss.ttf", 20)
leveltext = font1.render("???", False, colors.WHITE)

# main loop
run = True
while run:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.KEYDOWN:
            if event.mod & pygame.KMOD_CTRL:
                if pygame.key.get_pressed()[pygame.K_w]:
                    run = False

    if plat.escaped is True:
        plat.escaped = False
        levelcount += 1
        # print(levelcount)
        # print("escaped")
        currentlvl = levels[levelcount]
        leveltext = font1.render(f"Level {levelcount + 1} : {leveldescs[levelcount]}", False, colors.WHITE)

        prespacetiles.clear()
        spacetiles.empty()
        preblocktiles.clear()
        blocktiles.empty()
        prespawn = []
        spawn = Spawn(-10, -10)
        prelavatiles.clear()
        lavatiles.empty()
        preesctiles.clear()
        esctiles.empty()
        sprites.empty()

        for strip in currentlvl:
            for tile in strip:
                if tile == 0:
                    prespacetiles.append([levelx, levely])
                if tile == 1:
                    preblocktiles.append([levelx, levely])
                if tile == 2:
                    prespawn.append([levelx, levely])
                if tile == 3:
                    prelavatiles.append([levelx, levely])
                if tile == 4:
                    preesctiles.append([levelx, levely])
                levelx += 1 * size
            levelx = 0
            levely += 1 * size
        levely = 0

        for pre in prespacetiles:
            tile = Space(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            spacetiles.add(tile)
        for pre in preblocktiles:
            tile = Block(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            blocktiles.add(tile)
        for pre in prespawn:
            tile = Spawn(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            spawn = tile
        for pre in prelavatiles:
            tile = Lava(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            lavatiles.add(tile)
        for pre in preesctiles:
            tile = Esc(pre[0], pre[1])
            tile.rect.x, tile.rect.y = tile.x, tile.y
            esctiles.add(tile)
        print(preesctiles)
        if spawn == Spawn(-10, -10):
            print("Error: No spawn found")
            run = False

        die()
        sprites.add(plat, spacetiles, blocktiles, spawn, lavatiles, esctiles)

    if pygame.sprite.spritecollide(plat, lavatiles, False):
        die()
    if pygame.sprite.spritecollide(plat, esctiles, False):
        plat.escaped = True

    win.fill((0, 0, 0))
    redrawgamewindow()
pygame.quit()
